package com.sonu.testdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gohealth.demo.model.Person;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Person person = new Person();
    }
}